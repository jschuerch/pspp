module pspp07 {
    requires ch.zhaw.random;
    exports pspp07;
}