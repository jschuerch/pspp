Pharo 6.1

This distribution was built December 05, 2017.